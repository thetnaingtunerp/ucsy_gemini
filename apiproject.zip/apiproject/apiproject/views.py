from django.shortcuts import render,redirect
import google.generativeai as genai

from api.models import Msg

def chat(request):
    msg = Msg.objects.all()
    return render(request, 'index.html', {'msg':msg})

def askgemini(request):
    msg = request.POST.get('usermsg')
    genai.configure(api_key="AIzaSyCysy76DsD7oarMGWst60LmBBSytjnl-TI")
    model = genai.GenerativeModel("gemini-pro")
    bot_response = model.generate_content(msg)
    res = Msg.objects.create(usermsg=msg,botans=bot_response.text)
    # print(bot_response.text)
    return redirect('/chat/')