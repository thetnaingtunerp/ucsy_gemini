from django.db import models

class Msg(models.Model):
    usermsg = models.CharField(max_length=255)
    botans = models.TextField()